package Manifestacao;
import java.util.Date;

import Usuario.Usuario;

public class Manifestacao implements Auditavel {
    private Date dataManifestacao;
    private String descricao;
    private Categoria categoria;
    private Usuario autor;
    // Construtor
    public Manifestacao(Date dataManifestacao, String descricao, Categoria categoria){
        this.dataManifestacao = dataManifestacao;
        this.descricao = descricao;
        this.categoria = categoria;
        
    }
    public Manifestacao(){
    }

    public void setAutor(Usuario autor) {
        this.autor = autor;
    }
    
    public String getAutorManifestacao() {
        if (autor != null) {
            return autor.getNome();
        } else {
            return "Autor Desconhecido";
        }
    }
    
    // Sets e Gets
    public void setDataManifestacao(Date dataManifestacao){
        this.dataManifestacao = dataManifestacao;
    }
    public Date getDataManifestacao(){
        return dataManifestacao;
    }
    public void setDescricao(String descricao){
        this.descricao = descricao;
    }
    public String getDescricao(){
        return descricao;
    }

    public void setCategoria(Categoria categoria){
        this.categoria = categoria;
    }
    public Categoria getCategoria(){
        return categoria;
    }
}
