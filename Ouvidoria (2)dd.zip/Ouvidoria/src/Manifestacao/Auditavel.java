package Manifestacao;

public interface Auditavel {
    String getAutorManifestacao();
}
