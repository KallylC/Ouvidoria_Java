package Manifestacao;

public enum Categoria {
    RECLAMACAO, ELOGIO, SUGESTAO
}
