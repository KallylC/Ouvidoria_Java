import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import javax.swing.*;

import Manifestacao.*;
import Usuario.*;

public class Controller {
    private  ArrayList<Usuario> usuarioArray = new ArrayList<Usuario>();

    public Controller() {}

    public void run() {
        JOptionPane.showMessageDialog(null, "Bem vindo! Voce está no sistema da ouvidoria!", "Ouvidoria", 1);

        while (true){
            int menuInput = 0;
            String[] menu = { "Cadastrar", "Lista", "Sair"};
            menuInput = JOptionPane.showOptionDialog(null, "Escolha uma opção", "Ouvidoria - Menu", 0,  3, null, menu, menu[0]);

            if (menuInput == 2) {
                break;
            }

            switch(menuInput){
                case 0:
                    startCadastrar();
                    break;
                case 1:
                    startLista();
                    break;
            }
        }
    }

    private void startCadastrar(){ // metodo cadastrar
        int menuInput2 = 0;
        String[] menu2 = { "Manifestação", "Usuário", "Voltar"};
        menuInput2 = JOptionPane.showOptionDialog(null, "Escolha uma opção", "Ouvidoria - Cadastrar", 0, JOptionPane.QUESTION_MESSAGE, null, menu2, menu2[0]);

        switch (menuInput2){
            case 0: // Cadastrar uma manifestação
                registrarManifestacao();
                break;

            case 1: // Cadastrar um usuário
                registrarUsuario();
                break;
            case 2: // voltar para o menu
                break;
        }
    }
    private void startLista(){ // metodo Lista
        int menuInput = 0;
        String[] menu = { "Por dia", "Por Usuário", "Sair"};
        menuInput = JOptionPane.showOptionDialog(null, "Escolha como você quer mostrar as manifestações", "Ouvidoria - Lista", 0,  3, null, menu, menu[0]);

        switch(menuInput){
            case 0: // mostra a lista por dia
                listarPorDia();
                break;
            case 1: // mostra a lista por usuario
                manifestacaoPorUsuario();
                break;
            case 2: // volta para o menu principal
                break;
        }
    }
    private void registrarManifestacao() { // metodo registrar manifestação
        if (usuarioArray.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Nenhum usuário cadastrado! \nVocê precisa cadastrar um usuário primeiro.", "Ouvidoria - Manifestação", 2);
            return;
        }

        // mostra uma lista de usuarios existentes
        int index = 1;
        String nomeUsuarioLista = "Lista de usuários";
        for (Usuario usuario : usuarioArray){
            nomeUsuarioLista += "\n" + (index++) + "- " + usuario.getNome();
        }

        JOptionPane.showMessageDialog(null, nomeUsuarioLista, "Ouvidoria - Manifestação", JOptionPane.WARNING_MESSAGE);

        int menuInput3 = 0;
        String[] menu3 = { "Reclamação", "Sugestão", "Elogio"};
        menuInput3 = JOptionPane.showOptionDialog(null, "Escolha uma opção", "Ouvidoria - Cadastrar", 0,  3, null, menu3, menu3[0]);

        JTextField nomeUserInput = new JTextField();
        JTextField descricaoInput = new JTextField();
        Object[] message4 = {
            "Nome do usuário:", nomeUserInput,
            "Descrição:", descricaoInput,
        };

        JOptionPane.showConfirmDialog(null, message4, "Ouvidoria - Usuário - Professor", JOptionPane.OK_CANCEL_OPTION);

        if (seVazio(nomeUserInput, descricaoInput)){
            JOptionPane.showMessageDialog(null, "Erro ao cadastrar usuário! \n Campo de texto vázio!", "Ouvidoria", 0);
            return;
        }
        
        Date dataAtual = new Date(); // Obter a data atual
        Manifestacao manifestacao = new Manifestacao();
        manifestacao.setDataManifestacao(dataAtual);
        manifestacao.setDescricao(descricaoInput.getText());

        Usuario user = encontrarUsuario(nomeUserInput.getText());

        if (user == null) { // se não encontrar usuario com nomeUserInput, msg de erro
            JOptionPane.showMessageDialog(null, "Erro ao cadastrar usuário! \n Usuário com esse nome não existe!", "Ouvidoria", JOptionPane.ERROR_MESSAGE);
            return;
        } else { // se encontrar, add obj manifestação ao array dele
            manifestacao.setAutor(user);

            user.addManifestacao(manifestacao);
            JOptionPane.showMessageDialog(null, "Manifestação registrada!", "Ouvidoria", 2);
        }

        switch (menuInput3){
            case 0: // Reclamação
                manifestacao.setCategoria(Categoria.RECLAMACAO);
                break;
            case 1: // Sugestao
                manifestacao.setCategoria(Categoria.SUGESTAO);
                break;
            case 2: // Elogio
                manifestacao.setCategoria(Categoria.ELOGIO);
                break;
        }
    }
    private void registrarUsuario() { 
        int menuUsuario = 0;
        String[] menu3 = { "Professor", "Aluno", "Colaborador"};
        menuUsuario = JOptionPane.showOptionDialog(null, "Escolha uma opção", "Ouvidoria - Usuário", 0,  3, null, menu3, menu3[0]);
                                
        JTextField nomeInput = new JTextField();
        JTextField cpfInput = new JTextField();
        JTextField dataNasciInput = new JTextField();
                                    
        switch (menuUsuario){ 
            case 0: // Professor                    
                JTextField cargaHoraInput = new JTextField();
                Object[] message1 = {
                    "Nome:", nomeInput,
                    "CPF:", cpfInput,
                    "Data de Nascimento", dataNasciInput,
                    "Carga Horária", cargaHoraInput
                }; 
                int result1 = JOptionPane.showConfirmDialog(null, message1, "Ouvidoria - Professor", JOptionPane.OK_CANCEL_OPTION);
    
                if (result1 == JOptionPane.OK_OPTION && validarCPF(cpfInput.getText()) && validarDataNascimento(dataNasciInput.getText())) {
                    Professor professor = new Professor();
                    professor.setNome(nomeInput.getText());
                    professor.setCpf(cpfInput.getText());
                    professor.setDataNascimento(dataNasciInput.getText());
                    professor.setCargaHorario(cargaHoraInput.getText());
                    usuarioArray.add(professor);
                } else {
                    JOptionPane.showMessageDialog(null, "Dados inválidos! Por favor, verifique o CPF e a Data de Nascimento.", "Erro", JOptionPane.ERROR_MESSAGE);
                    registrarUsuario(); // Chama novamente o método para solicitar os dados corretos
                }
                break;
            
            case 1: // Aluno
                JTextField media = new JTextField();
                Object[] message2 = {
                    "Nome:", nomeInput,
                    "CPF:", cpfInput,
                    "Data de Nascimento", dataNasciInput,
                    "Media", media
                };
                int result2 = JOptionPane.showConfirmDialog(null, message2, "Ouvidoria - Aluno", JOptionPane.OK_CANCEL_OPTION);
    
                if (result2 == JOptionPane.OK_OPTION && validarCPF(cpfInput.getText()) && validarDataNascimento(dataNasciInput.getText())) {
                    Aluno aluno = new Aluno();
                    aluno.setNome(nomeInput.getText());
                    aluno.setCpf(cpfInput.getText());
                    aluno.setDataNascimento(dataNasciInput.getText());
                    aluno.setMedia(media.getText());
                    usuarioArray.add(aluno);
                } else {
                    JOptionPane.showMessageDialog(null, "Dados inválidos! Por favor, verifique o CPF e a Data de Nascimento.", "Erro", JOptionPane.ERROR_MESSAGE);
                    registrarUsuario(); // Chama novamente o método para solicitar os dados corretos
                }
                break;
                                            
            case 2: // Colaborador
                JTextField setor = new JTextField();
                Object[] message3 = {
                    "Nome:", nomeInput,
                    "CPF:", cpfInput,
                    "Data de Nascimento", dataNasciInput,
                    "Setor", setor
                };
                int result3 = JOptionPane.showConfirmDialog(null, message3, "Ouvidoria - Colaborador", JOptionPane.OK_CANCEL_OPTION);
    
                if (result3 == JOptionPane.OK_OPTION && validarCPF(cpfInput.getText()) && validarDataNascimento(dataNasciInput.getText())) {
                    Colaborador colaborador = new Colaborador();
                    colaborador.setNome(nomeInput.getText());
                    colaborador.setCpf(cpfInput.getText());
                    colaborador.setDataNascimento(dataNasciInput.getText());
                    colaborador.setSetor(setor.getText());
                    usuarioArray.add(colaborador);
                } else {
                    JOptionPane.showMessageDialog(null, "Dados inválidos! Por favor, verifique o CPF e a Data de Nascimento.", "Erro", JOptionPane.ERROR_MESSAGE);
                    registrarUsuario(); // Chama novamente o método para solicitar os dados corretos
                }
                break;
        }          
    }
    
    
    private void listarPorDia() { // metodo Lista por dia 

        List<Manifestacao> todasManifestacoes = getManifestacaos(); 

        SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");
        format.setLenient(false);
    
        String dataStr = JOptionPane.showInputDialog(null, "Digite a data que gostaria de ver, formato (dd/MM/yyyy)");
        if (dataStr == null || dataStr.trim().isEmpty()) {
            return;
        }
    
        try { 
            Date data = format.parse(dataStr);
            StringBuilder sb = new StringBuilder();
            boolean encontrou = false;
            for (Manifestacao manifestacao : todasManifestacoes) {
                if (isMesmoDia(manifestacao.getDataManifestacao(), data)) {
                    sb.append("Data: ").append(format.format(manifestacao.getDataManifestacao())).append("\n")
                      .append("Autor: ").append(manifestacao.getAutorManifestacao()).append("\n") // Adicionando o autor aqui
                      .append("Tipo: ").append(manifestacao.getCategoria()).append("\n")
                      .append("Descrição: ").append(manifestacao.getDescricao()).append("\n")
                      .append("------------------------------------\n");
                    encontrou = true;
                }
            }
    
            if (!encontrou) {
                JOptionPane.showMessageDialog(null, "Nenhuma manifestação encontrada para a data especificada.");
            } else {
                JOptionPane.showMessageDialog(null, sb.toString());
            }
        } catch (ParseException e) {
            JOptionPane.showMessageDialog(null, "Formato de data inválido.");
        }
    }
    
    private void manifestacaoPorUsuario() { // metodo Lista por usuario comparar dia input com Manifestação

        String nomeUsuario = JOptionPane.showInputDialog(null, "Digite o nome do usuário para ver suas manifestações:");
        if (nomeUsuario != null && !nomeUsuario.trim().isEmpty()) {
            Usuario usuario = encontrarUsuario(nomeUsuario);
            if (usuario != null) {
                List<Manifestacao> manifestacoesUsuario = usuario.getManifestacoes();
                if (!manifestacoesUsuario.isEmpty()) {
                    StringBuilder sb = new StringBuilder();
                    sb.append("Manifestações de ").append(nomeUsuario).append(":\n\n");
                    SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
                    for (Manifestacao manifestacao : manifestacoesUsuario) {
                        sb.append("Data: ").append(dateFormat.format(manifestacao.getDataManifestacao())).append("\n")
                          .append("Tipo: ").append(manifestacao.getCategoria()).append("\n")
                          .append("Descrição: ").append(manifestacao.getDescricao()).append("\n")
                          .append("------------------------------------\n");
                    }
                    JOptionPane.showMessageDialog(null, sb.toString(), "Manifestações por Usuário", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(null, "Não há manifestações registradas para o usuário: " + nomeUsuario, "Manifestações por Usuário", JOptionPane.INFORMATION_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(null, "Usuário não encontrado: " + nomeUsuario, "Manifestações por Usuário", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(null, "Nome do usuário inválido!", "Manifestações por Usuário", JOptionPane.ERROR_MESSAGE);
        }
    }

    private boolean isMesmoDia(Date data1, Date data2) { // metodo usasdo para 
        SimpleDateFormat fmt = new SimpleDateFormat("dd/MM/yyyy");
        return fmt.format(data1).equals(fmt.format(data2));
    }
    private Usuario encontrarUsuario(String nome) { // metodo usasdo para encontrar o usuario em metodo registrarManifestacao
        for (Usuario usuario : usuarioArray) { // busca no array de Usuarios por nome igual ao input do usuario
            if (usuario.getNome().equals(nome)) {
                return usuario;
            }
        }
        return null;
    }
    private boolean validarCPF(String cpf) {
        // Remove caracteres não numéricos do CPF
        cpf = cpf.replaceAll("[^0-9]", "");
    
        // Verifica se o CPF possui 11 dígitos
        if (cpf.length() != 11) {
            return false;
        }
    
        // Calcula o primeiro dígito verificador
        int soma = 0;
        for (int i = 0; i < 9; i++) {
            soma += Character.getNumericValue(cpf.charAt(i)) * (10 - i);
        }
        int primeiroDigito = 11 - (soma % 11);
        if (primeiroDigito == 10 || primeiroDigito == 11) {
            primeiroDigito = 0;
        }
    
        // Verifica o primeiro dígito verificador
        if (Character.getNumericValue(cpf.charAt(9)) != primeiroDigito) {
            return false;
        }
    
        // Calcula o segundo dígito verificador
        soma = 0;
        for (int i = 0; i < 10; i++) {
            soma += Character.getNumericValue(cpf.charAt(i)) * (11 - i);
        }
        int segundoDigito = 11 - (soma % 11);
        if (segundoDigito == 10 || segundoDigito == 11) {
            segundoDigito = 0;
        }
    
        // Verifica o segundo dígito verificador
        if (Character.getNumericValue(cpf.charAt(10)) != segundoDigito) {
            return false;
        }
    
        return true;
    }
    
    private boolean validarDataNascimento(String dataNascimento) {
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        sdf.setLenient(false);
    
        try {
            // Parse da data de nascimento
            sdf.parse(dataNascimento);
            return true;
        } catch (ParseException e) {
            return false;
        }
    }
    private List<Manifestacao> getManifestacaos() { // cria um array com todos os arrays de manifestacoes juntos
        ArrayList<Manifestacao> todasManifestacoes = new ArrayList<Manifestacao>();
        for (Usuario usuario : usuarioArray) {
            todasManifestacoes.addAll(usuario.getManifestacoes());
        }
        return todasManifestacoes;
      }
    private static boolean seVazio(JTextField... fields) { // metodo para verificar se o campo ta vazio
        for (JTextField field : fields) {
            if (field.getText().isEmpty()) {
                return true;
            }
        }
        return false;
    }
}
