package Usuario;
import java.util.Date;

public class Professor extends Usuario{
    private String cargaHorario;
    
    // Construtor professor
    public Professor(String nome, String cpf, Date dataNascimento, String cargaHorario){
        super(nome, cpf, dataNascimento);
        this.cargaHorario = cargaHorario;
    }
    public Professor(){
    }
    
    // Sets e Gets
    public void setCargaHorario(String cargaHorario){
        this.cargaHorario = cargaHorario;
    }
    public String getCargaHorario(){
        return cargaHorario;
    }
}
