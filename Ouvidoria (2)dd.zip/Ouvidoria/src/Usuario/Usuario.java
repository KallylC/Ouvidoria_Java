package Usuario;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import Manifestacao.*;

public abstract class Usuario implements Auditavel {
    private String nome;
    private String cpf;
    private Date dataNascimento;
    private ArrayList<Manifestacao> manifestacoes = new ArrayList<Manifestacao>();

    public Usuario(String nome, String cpf, Date dataNascimento) { 
        this.nome = nome;
        this.cpf = cpf;
        this.dataNascimento = dataNascimento;
    }

    public Usuario() {
    }

    public void addManifestacao(Manifestacao manifestacao) {
        manifestacoes.add(manifestacao);
    }

    @Override
    public String getAutorManifestacao() {
        return getNome();
    }

    // sets e gets
    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getNome() {
        return nome;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getCpf() {
        return cpf;
    }

    public void setDataNascimento(Date dataNascimento) { // Alterado para Date
        this.dataNascimento = dataNascimento;
    }
    
    public void setDataNascimento(String dataNascimento) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy");
        try {
            this.dataNascimento = dateFormat.parse(dataNascimento);
        } catch (ParseException e) {
            System.out.println("Erro ao converter data de nascimento.");
            e.printStackTrace();
        }
    }
    public Date getDataNascimento() { // Alterado para Date
        return dataNascimento;
    }

    public ArrayList<Manifestacao> getManifestacoes() { // Alterado o nome do método
        return manifestacoes;
    }
}
