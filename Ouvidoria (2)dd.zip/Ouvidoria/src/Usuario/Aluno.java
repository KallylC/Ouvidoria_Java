package Usuario;

import java.util.Date;

public class Aluno extends Usuario{
    private String media;

    // Construtor aluno
    public Aluno(String nome, String cpf, Date dataNascimento, String media){
        super(nome, cpf, dataNascimento);
        this.media = media;
    }
    public Aluno(){
    }

    // Sets e Gets
    public void setMedia(String media){
        this.media = media;
    }
    public String getMedia(){
        return media;
    }
}
