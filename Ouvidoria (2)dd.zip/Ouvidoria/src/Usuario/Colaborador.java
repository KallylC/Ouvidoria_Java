package Usuario;
import java.util.Date;

public class Colaborador extends Usuario{
    private String setor;
    
    // Construtor colaborador
    public Colaborador(String nome, String cpf, Date dataNascimento, String setor){
        super(nome, cpf, dataNascimento);
        this.setor = setor;
    }
    public Colaborador(){
    }

    // Sets e Gets
    public void setSetor(String setor){
        this.setor = setor;
    }
    public String getSetor(){
        return setor;
    }
    
}
